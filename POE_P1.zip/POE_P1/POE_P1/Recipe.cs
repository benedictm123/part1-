﻿namespace part1Poe
{
    internal class Recipe
    {
        public object Ingredients { get; internal set; }
    }
}